#!/bin/bash
#
#Passer en argument [start|stop|restart]

ch=$(pwd)
cd /etc/init.d/
for i in $( ls nova-* )
	do
		service $i $1
	done
cd 
cd $ch
