#!/bin/bash

# (fr)
# Ce script permet d'automatiser l'installation du noeud "Controller" dans une configuration OpenStack
# (en)
# This script enable to automate the "Comtroller" node installation for OpenStack

# Copyright 2013 GON Jérôme 
# (jerome.gon@gmx.fr)
#
# Licence GNU GPLv3 
#
# This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# (fr)
## Prérequis :
#
# un serveur avec deux interfaces actives
# ubuntu server 12.04
# Protocole :
# 	$ tar -xf install_controlleur-x.x.x.tar.gz
# 	$ cd install_controlleur
#	$ vi controller.sh #modif les variables
#	$ sudo su
#	# chmod +x *.sh
#	# ./controller.sh
#
# (en)
## Required
#
# one server with tow network interfaces
# Ubuntu server 12.04
# Instructions :
# 	$ tar -xf install_controlleur-x.x.x.tar.gz
# 	$ cd install_controlleur
#	$ vi controller.sh #set variables
#	$ sudo su
#	# chmod +x *.sh
#	# ./controller.sh
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
## variables Initialisation:
#
# hostname
export Nom="Controller"
# Pwd root :
export MdP="Atom3s"
# management IP :
export Int_manage="eth1"
export IP_manage="10.0.2.10"
export Mask_manage="255.255.255.0"
# LAN IP :
export Int_local="eth0"
export IP_local="172.16.1.70"
export Mask_local="255.255.255.0"
export Gateway_local="172.16.1.1"
export DNS_local="8.8.8.8"
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
### hostname
echo "[[[[[[[[[[[[[[[[[[[[ Paramétrage du nom ]]]]]]]]]]]]]]]]]]]]]]]]"
rm '/etc/hostname'
echo "$Nom" >> '/etc/hostname'

### network
echo "[[[[[[[[[[[[[[[[[[[[ Paramétrage réseau ]]]]]]]]]]]]]]]]]]]]]]]]"
rm /etc/network/interfaces
echo -e "#loopback\nauto lo\niface lo inet loopback\n\n#For Exposing OpenStack API over the internet\nauto $Int_local\niface $Int_local inet static\n\taddress $IP_local\n\tnetmask $Mask_local\n\tgateway $Gateway_local\n\tdns-nameservers $DNS_local\n\n#OpenStack management\nauto $Int_manage\niface $Int_manage inet static\n\taddress $IP_manage\n\tnetmask $Mask_manage\n" >> /etc/network/interfaces
ifup '$Int_local'
ifup '$Int_manage'
ifdown '$Int_local'
ifdown '$Int_manage'
ifup '$Int_local'
ifup '$Int_manage'

### update
echo "[[[[[[[[[[[[[[[[[[[[[[[[[ MAJ ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get update
apt-get -y upgrade

### folsom reposytori
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[ Modif dépot ]]]]]]]]]]]]]]]]]]]]]]]]]"
echo "deb http://ubuntu-cloud.archive.canonical.com/ubuntu precise-updates/folsom main" >> /etc/apt/sources.list.d/folsom.list
apt-get install -y ubuntu-cloud-keyring
apt-get update
apt-get -y upgrade

### mysql & rabbitmq
echo "[[[[[[[[[[[[[[[[[[ installation mysql & rabbit ]]]]]]]]]]]]]]]]]"
apt-get install -y mysql-server python-mysqldb
# mysql configuration
sed -i 's/127.0.0.1/0.0.0.0/g' /etc/mysql/my.cnf

service mysql restart
apt-get install -y rabbitmq-server

### ntp
echo "[[[[[[[[[[[[[[[[[[[[[[[[[ paramétrage ntp ]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y ntp
sed -i 's/server ntp.ubuntu.com/server ntp.ubuntu.com\nserver 127.127.1.0\nfudge 127.127.1.0 stratum 10/g' /etc/ntp.conf

service ntp restart

### use packages
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ outils ]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y vlan bridge-utils
sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
sysctl net.ipv4.ip_forward=1

### keystone
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ keystone ]]]]]]]]]]]]]]]]]]]]]])]]]]"
apt-get install -y keystone
# keystone database creation
mysql -p$Mdp <<EOF
CREATE DATABASE keystone;
GRANT ALL PRIVILEGES ON keystone.* TO 'keystone'@'%' IDENTIFIED BY '$Mdp';
GRANT ALL PRIVILEGES ON keystone.* TO 'keystone'@'localhost' IDENTIFIED BY '$Mdp';
EOF
# keystone configuration
sed -i 's/connection =.*//' /etc/keystone/keystone.conf
sed -i 's/# The SQLAlchemy connection string used to connect to the database/&\nconnection = mysql:\/\/keystone:'"$MdP"'@'"$IP_manage"'\/keystone/' /etc/keystone/keystone.conf

service keystone restart
keystone-manage db_sync
# init+exec of keystone.sh and endpoints.sh scripts
sed -i 's/MotDePasse/'"$MdP"'/' keystone.sh
chmod +x keystone.sh
./keystone.sh
sed -i 's/MotDePasse/'"$MdP"'/' endpoints.sh
sed -i 's/IP_manage/'"$IP_manage"'/' endpoints.sh
sed -i 's/IP_local/'"$IP_local"'/' endpoints.sh
chmod +x endpoints.sh
./endpoints.sh
# set environement variables
echo -e "export OS_TENANT_NAME=admin\nexport OS_USERNAME=admin\nexport OS_PASSWORD=$MdP\nexport OS_AUTH_URL=http://$IP_local:5000/v2.0/" >> creds
source creds

# glance
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[ glance ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y glance
# glance data base creation
mysql -p$Mdp <<EOF
CREATE DATABASE glance;
GRANT ALL PRIVILEGES ON glance.* TO 'glance'@'%' IDENTIFIED BY '$Mdp';
GRANT ALL PRIVILEGES ON glance.* TO 'glance'@'localhost' IDENTIFIED BY '$Mdp';
EOF
# glance configuration
sed -i 's/delay_auth_decision = true//' /etc/glance/glance-api-paste.ini
echo -e "auth_host = $IP_manage\nauth_port = 35357\nauth_protocol = http\nadmin_tenant_name = service\nadmin_user = glance\nadmin_password = $MdP\n" >> /etc/glance/glance-api-paste.ini
echo -e "auth_host = $IP_manage\nauth_port = 35357\nauth_protocol = http\nadmin_tenant_name = service\nadmin_user = glance\nadmin_password = $MdP\n" >> /etc/glance/glance-registry-paste.ini
sed -i 's/sql_connection =.*//' /etc/glance/glance-api.conf
sed -i 's/# See:.*//' /etc/glance/glance-api.conf
sed -i 's/# registry server. Any valid SQLAlchemy connection string is fine./&\nsql_connection = mysql:\/\/glance:'"$MdP"'@'"$IP_manage"'\/glance/' /etc/glance/glance-api.conf
sed -i 's/#flavor=/flavor = keystone/' /etc/glance/glance-api.conf
sed -i 's/sql_connection =.*//' /etc/glance/glance-registry.conf
sed -i 's/# See:.*//' /etc/glance/glance-registry.conf
sed -i 's/# registry server. Any valid SQLAlchemy connection string is fine./&\nsql_connection = mysql:\/\/glance:'"$MdP"'@'"$IP_manage"'\/glance/' /etc/glance/glance-registry.conf
sed -i 's/#flavor=/flavor = keystone/' /etc/glance/glance-registry.conf

service glance-api restart
service glance-registry restart

### quantum
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[ quantum ]]]]]]]]]]]]]]]]]]]]]]]"
rabbitmqctl change_password guest $MdP

apt-get -y install quantum-server quantum-plugin-openvswitch
# quantum data base creation
mysql -p$MdP <<EOF
CREATE DATABASE quantum;
GRANT ALL PRIVILEGES ON quantum.* TO 'quantum'@'%' IDENTIFIED BY '$Mdp';
GRANT ALL PRIVILEGES ON quantum.* TO 'quantum'@'localhost' IDENTIFIED BY '$Mdp';
EOF
# quantum configuration
sed -i 's/sql_connection =.*//' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# main quantum server. (Leave it as is if the database runs on this host.)/&\nsql_connection = mysql:\/\/quantum:'"$MdP"'@'"$IP_manage"'\/quantum/' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# Example: tenant_network_type = gre/tenant_network_type = vlan/' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# Default: network_vlan_ranges =/tunnel_id_ranges = physnet1:1:4094/' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# rabbit_host = localhost/rabbit_host = 127.0.0.1/' /etc/quantum/quantum.conf
sed -i 's/# rabbit_password = guest/rabbit_password = '"$MdP"'/' /etc/quantum/quantum.conf
sed -i 's/# rabbit_userid = guest/rabbit_userid = guest/' /etc/quantum/quantum.conf 
sed -i 's/auth_host = 127.0.0.1/auth_host = '"$IP_manage"'/' /etc/quantum/api-paste.ini
sed -i 's/%SERVICE_TENANT_NAME%/service/' /etc/quantum/api-paste.ini
sed -i 's/%SERVICE_USER%/quantum/' /etc/quantum/api-paste.ini
sed -i 's/%SERVICE_PASSWORD%/'"$MdP"'/' /etc/quantum/api-paste.ini

service quantum-server restart

### nova
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ nova ]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y nova-api nova-cert novnc nova-consoleauth nova-scheduler nova-novncproxy
# nova data base creation
mysql -p$MdP <<EOF
CREATE DATABASE nova;
GRANT ALL PRIVILEGES ON nova.* TO 'nova'@'%' IDENTIFIED BY '$Mdp';
GRANT ALL PRIVILEGES ON nova.* TO 'nova'@'localhost' IDENTIFIED BY '$Mdp';
EOF
# nova configuration
sed -i 's/auth_host = 127.0.0.1/auth_host = '"$IP_manage"'/' /etc/nova/api-paste.ini
sed -i 's/%SERVICE_TENANT_NAME%/service/' /etc/nova/api-paste.ini
sed -i 's/%SERVICE_USER%/nova/' /etc/nova/api-paste.ini
sed -i 's/%SERVICE_PASSWORD%/'"$MdP"'/' /etc/nova/api-paste.ini
rm /etc/nova/nova.conf
sed -i 's/100.10.10.51/'"$IP_manage"'/g' nova.conf
sed -i 's/novaUser/nova/g' nova.conf
sed -i 's/novaPass/'"$MdP"'/g' nova.conf
sed -i 's/192.168.100.51/'"$IP_local"'/g' nova.conf
sed -i 's/service_pass/'"$MdP"'/g' nova.conf
cp nova.conf /etc/nova/nova.conf

mysqladmin -p$MdP flush-hosts
chmod +x nova_service.sh
./nova_service.sh restart
nova-manage db sync
./nova_service.sh restart

###############[[[[[[[[[[[[[[[[[ PB NOVA ]]]]]]]]]]]]]]]]]]]]###############
#error :
#DEBUG nova.utils [-] backend <module 'nova.db.sqlalchemy.migration' from '/usr/lib/python2.7/dist-packages/nova/db/sqlalchemy/migration.pyc'> __get_backend /usr/lib/python2.7/dist-packages/nova/utils.py:506

### cinder
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[ cinder ]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y cinder-api cinder-scheduler cinder-volume iscsitarget open-iscsi iscsitarget-dkms
sed -i 's/false/true/g' /etc/default/iscsitarget
service iscsitarget start
service open-iscsi start
# cinder data base creation
mysql -p$MdP <<EOF
CREATE DATABASE cinder;
GRANT ALL PRIVILEGES ON cinder.* TO 'cinder'@'%' IDENTIFIED BY '$Mdp';
GRANT ALL PRIVILEGES ON cinder.* TO 'cinder'@'localhost' IDENTIFIED BY '$Mdp';
EOF
# cinder configuration
sed -i 's/service_host = 127.0.0.1/auth_host = '"$IP_local"'/' /etc/cinder/api-paste.ini
sed -i 's/auth_host = 127.0.0.1/auth_host = '"$IP_manage"'/' /etc/cinder/api-paste.ini
sed -i 's/%SERVICE_TENANT_NAME%/service/' /etc/cinder/api-paste.ini
sed -i 's/%SERVICE_USER%/cinder/' /etc/cinder/api-paste.ini
sed -i 's/%SERVICE_PASSWORD%/'"$MdP"'/' /etc/cinder/api-paste.ini
echo "sql_connection = mysql://cinder:$MdP@$IP_local/cinder" >> /etc/cinder/cinder.conf
sed -i 's/iscsi_helper =/iscsi_helper = ietadm/' /etc/cinder/cinder.conf

cinder-manage db sync

#création d'un espace pour cinder [[[[[[[[[[[[[ A FAIRE ]]]]]]]]]]]]]

service cinder-volume restart
service cinder-api restart

### horizon
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[ horizon ]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y openstack-dashboard memcached
service apache2 restart; service memcached restart
