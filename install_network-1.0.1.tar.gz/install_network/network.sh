#!/bin/bash

# (fr)
# Ce script permet d'automatiser l'installation du noeud "Network" dans une configuration OpenStack
# (en)
# This script enable to automate the "Comtroller" node installation for OpenStack

# Copyright 2013 GON Jérôme 
# (jerome.gon@gmx.fr)
#
# Licence GNU GPLv3 
#
# This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# (fr)
## Prérequis :
#
# un serveur avec trois interfaces actives
# ubuntu server 12.04
# Protocole :
# 	$tar -xf install_network-x.x.x.tar.gz
# 	$cd install_network
#	$nano network.sh #modif les variables
#	$sudo su
#	#chmod +x *.sh
#	#./network.sh
# (en)
## Required
#
# one server with three network interfaces
# Ubuntu server 12.04
# Instructions :
# 	$ tar -xf install_network-x.x.x.tar.gz
# 	$ cd install_network
#	$ vi network.sh #set variables
#	$ sudo su
#	# chmod +x *.sh
#	# ./network.sh
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
## variables Initialisation :
#
# hostname
export Nom="Network"
# Pwd root :
export MdP="Atom3s"
# management IP :
export Int_manage="eth2"
export IP_manage="10.0.2.11"
export Mask_manage="255.255.255.0"
# LAN IP :
export Int_local="eth1"
export IP_local="172.16.1.71"
export Mask_local="255.255.255.0"
export Gateway_local="172.16.1.1"
export DNS_local="8.8.8.8"
# IP to communicate with compute :
export Int_com="eth3"
export IP_com="10.0.3.11"
export Mask_com="255.255.255.0"
# controlleur IP :
export IP_contro_manage="10.0.2.10"
export IP_contro_local="172.16.1.70"
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
### hostname
echo "[[[[[[[[[[[[[[[[[[[[ Paramétrage du nom ]]]]]]]]]]]]]]]]]]]]]]]]"
rm '/etc/hostname'
echo "$Nom" >> '/etc/hostname'

### network
echo "[[[[[[[[[[[[[[[[[[[[ Paramétrage réseau ]]]]]]]]]]]]]]]]]]]]]]]]"
rm /etc/network/interfaces
echo -e "#loopback\nauto lo\niface lo inet loopback\n\n#For Exposing OpenStack API over the internet\nauto $Int_local\niface $Int_local inet static\n\taddress $IP_local\n\tnetmask $Mask_local\n\tgateway $Gateway_local\n\tdns-nameservers $DNS_local\n\n#OpenStack management\nauto $Int_manage\niface $Int_manage inet static\n\taddress $IP_manage\n\tnetmask $Mask_manage\n# VM Configuration\n\nauto $Int_com\niface $Int_com inet static\n\taddress $IP_com\nnetmask $Mask_com" >> /etc/network/interfaces
ifup '$Int_local'
ifup '$Int_manage'
ifup '$Int_com'
ifdown '$Int_local'
ifdown '$Int_manage'
ifdown '$Int_com'
ifup '$Int_local'
ifup '$Int_manage'
ifup '$Int_com'

### update
echo "[[[[[[[[[[[[[[[[[[[[[[[[[ MAJ ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get update
apt-get -y upgrade

### folsom repo
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[ Modif dépot ]]]]]]]]]]]]]]]]]]]]]]]]]"
echo "deb http://ubuntu-cloud.archive.canonical.com/ubuntu precise-updates/folsom main" >> /etc/apt/sources.list.d/folsom.list
apt-get install -y ubuntu-cloud-keyring
apt-get update
apt-get -y upgrade

### ntp
echo "[[[[[[[[[[[[[[[[[[[[[[[[[ paramétrage ntp ]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y ntp
sed -i 's/server ntp.ubuntu.com/server '"$IP_contro_manage"'/g' /etc/ntp.conf
service ntp restart

### util packages
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ outils ]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y vlan bridge-utils
sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
sysctl net.ipv4.ip_forward=1

### OpenVSwitch
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ OVS ]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y openvswitch-switch openvswitch-datapath-dkms
ovs-vsctl add-br br-int
#br-eth1 will be used for VM configuration
ovs-vsctl add-br br-com
ovs-vsctl add-port br-com '$Int_com'
#br-ex is used to make to VM accessible from the internet
ovs-vsctl add-br br-ex

### quantum
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ quantum ]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get -y install quantum-plugin-openvswitch-agent quantum-dhcp-agent quantum-l3-agent
# quantum configuration
sed -i 's/auth_host = 127.0.0.1/auth_host = '"$IP_contro_manage"'/' /etc/quantum/api-paste.ini
sed -i 's/%SERVICE_TENANT_NAME%/service/' /etc/quantum/api-paste.ini
sed -i 's/%SERVICE_USER%/quantum/' /etc/quantum/api-paste.ini
sed -i 's/%SERVICE_PASSWORD%/'"$MdP"'/' /etc/quantum/api-paste.ini
sed -i 's/sql_connection =.*//' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# main quantum server. (Leave it as is if the database runs on this host.)/&\nsql_connection = mysql:\/\/quantum:'"$MdP"'@'"$IP_contro_manage"'\/quantum/' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# Example: tenant_network_type = gre/tenant_network_type = vlan/' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# Default: network_vlan_ranges =/tunnel_id_ranges = physnet1:1:4094/' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# Default: bridge_mappings =/bridge_mappings = physnet1:br-com/' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/auth_url =.*//' /etc/quantum/l3_agent.ini
sed -i 's/# The Quantum user information for accessing the Quantum API./&\nauth_url = http://'"$IP_contro_manage"':35357/v2.0/' /etc/quantum/l3_agent.ini
sed -i 's/%SERVICE_TENANT_NAME%/service/' /etc/quantum/l3_agent.ini
sed -i 's/%SERVICE_USER%/quantum/' /etc/quantum/l3_agent.ini
sed -i 's/%SERVICE_PASSWORD%/'"$MdP"'/' /etc/quantum/l3_agent.ini
sed -i 's/# metadata_ip =/metadata_ip = '"$IP_contro_local"'/' /etc/quantum/l3_agent.ini
sed -i 's/# metadata_port = 8775/metadata_port = 8775/' /etc/quantum/l3_agent.ini
sed -i 's/# rabbit_host = localhost/rabbit_host = '"$IP_contro_manage"'/' /etc/quantum/quantum.conf
sed -i 's/# rabbit_password = guest/rabbit_password = '"$MdP"'/' /etc/quantum/quantum.conf
sed -i 's/# rabbit_userid = guest/rabbit_userid = guest/' /etc/quantum/quantum.conf

service quantum-plugin-openvswitch-agent restart
service quantum-dhcp-agent restart
service quantum-l3-agent restart

ovs-vsctl add-port br-ex '$Int_local'
