#!/bin/bash

# (fr)
# Ce script permet d'automatiser l'installation du noeud "Compute" dans une configuration OpenStack
# (en)
# This script enable to automate the "Compute" node installation for OpenStack

# Copyright 2013 GON Jérôme 
# (jerome.gon@gmx.fr)
#
# Licence GNU GPLv3 
#
# This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# (fr)
## Prérequis :
#
# un serveur avec deux interfaces actives
# lui rajouter une patte sur internet le temps de l'install
# ubuntu server 12.04
# Protocole :
# 	$tar -xf install_compute-x.x.x.tar.gz
# 	$cd install_compute
#	$vi compute.sh #modif les variables
#	$sudo su
#	#chmod +x *.sh
#	#./compute.sh
#
# (en)
## Required
#
# one server with tow network interfaces
# one suplementary interface during the installation
# Ubuntu server 12.04
# Instructions :
# 	$tar -xf install_compute-x.x.x.tar.gz
# 	$cd install_compute
#	$vi compute.sh #set variables
#	$sudo su
#	#chmod +x *.sh
#	#./compute.sh
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
## variables Initialisation:
#
# hostname
export Nom="Compute"
# Pwd root :
export MdP="Atom3s"
# management IP :
export Int_manage="eth1"
export IP_manage="10.0.2.12"
export Mask_manage="255.255.255.0"
# compute IP :
export Int_comp="eth3"
export IP_comp="10.0.3.12"
export Mask_comp="255.255.255.0"
# controlleur IP :
export IP_contro_manage="10.0.2.10"
export IP_contro_local="172.16.1.70"
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
### set hostnamme
echo "[[[[[[[[[[[[[[[[[[[[ Paramétrage du nom ]]]]]]]]]]]]]]]]]]]]]]]]"
rm '/etc/hostname'
echo "$Nom" >> '/etc/hostname'

### set network
echo "[[[[[[[[[[[[[[[[[[[[ Paramétrage réseau ]]]]]]]]]]]]]]]]]]]]]]]]"
rm /etc/network/interfaces
echo -e "#loopback\nauto lo\niface lo inet loopback\n\n#For Exposing OpenStack API over the internet\nauto $Int_comp\niface $Int_comp inet static\n\taddress $IP_comp\n\tnetmask $Mask_comp\n\n#OpenStack management\nauto $Int_manage\niface $Int_manage inet static\n\taddress $IP_manage\n\tnetmask $Mask_manage\n" >> /etc/network/interfaces
ifup '$Int_comp'
ifup '$Int_manage'
ifdown '$Int_comp'
ifdown '$Int_manage'
ifup '$Int_comp'
ifup '$Int_manage'

### update
echo "[[[[[[[[[[[[[[[[[[[[[[[[[ MAJ ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get update
apt-get -y upgrade

### folsom reposytories
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[ Modif dépot ]]]]]]]]]]]]]]]]]]]]]]]]]"
echo "deb http://ubuntu-cloud.archive.canonical.com/ubuntu precise-updates/folsom main" >> /etc/apt/sources.list.d/folsom.list
apt-get install -y ubuntu-cloud-keyring
apt-get update
apt-get -y upgrade

### ntp
echo "[[[[[[[[[[[[[[[[[[[[[[[[[ paramétrage ntp ]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y ntp
sed -i 's/server ntp.ubuntu.com/server '"$IP_contro_manage"'/g' /etc/ntp.conf
service ntp restart

### util packages
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ outils ]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y vlan bridge-utils
sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
sysctl net.ipv4.ip_forward=1

### kvm
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ KVM ]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y cpu-checker
kvm-ok
apt-get install -y kvm libvirt-bin pm-utils
echo -e "\ncgroup_device_acl = [\n\"/dev/null\", \"/dev/full\", \"/dev/zero\",\n\"/dev/random\", \"/dev/urandom\",\n\"/dev/ptmx\", \"/dev/kvm\", \"/dev/kqemu\",\n\"/dev/rtc\", \"/dev/hpet\",\"/dev/net/tun\"\n]" >> /etc/libvirt/qemu.conf
virsh net-destroy default
virsh net-undefine default
sed -i 's/#listen_tls = 0/listen_tls = 0/' /etc/libvirt/libvirtd.conf
sed -i 's/#listen_tcp = 1/listen_tcp = 1/' /etc/libvirt/libvirtd.conf
sed -i 's/#auth_tcp = "sasl"/auth_tcp = "none"/' /etc/libvirt/libvirtd.conf
sed -i 's/env libvirtd_opts="-d"/env libvirtd_opts="-d -l"/' /etc/init/libvirt-bin.conf
sed -i 's/libvirtd_opts="-d"/libvirtd_opts="-d -l"/' /etc/default/libvirt-bin
service libvirt-bin restart

### OVS
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ OVS ]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get install -y openvswitch-switch openvswitch-datapath-dkms
#br-int will be used for VM integration
ovs-vsctl add-br br-int
#br-eth1 will be used for VM configuration
ovs-vsctl add-br br-comp
ovs-vsctl add-port br-comp '$Int_comp'

### quantum
echo "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[ quantum ]]]]]]]]]]]]]]]]]]]]]]]]]]]"
apt-get -y install quantum-plugin-openvswitch-agent
###### to continue...
sed -i 's/sql_connection =.*//' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
sed -i 's/# main quantum server. (Leave it as is if the database runs on this host.)/&\nsql_connection = mysql:\/\/quantum:'"$MdP"'@'"$IP_contro_manage"'\/quantum/' /etc/quantum/plugins/openvswitch/ovs_quantum_plugin.ini
